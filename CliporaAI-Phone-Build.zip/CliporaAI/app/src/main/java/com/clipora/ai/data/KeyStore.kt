package com.clipora.ai.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class KeyStore(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "clipora_secure_settings",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getGeminiKey(): String = prefs.getString("gemini_key", "").orEmpty()
    fun getGroqKey(): String = prefs.getString("groq_key", "").orEmpty()
    fun saveKeys(gemini: String, groq: String) {
        prefs.edit().putString("gemini_key", gemini.trim())
            .putString("groq_key", groq.trim()).apply()
    }
}
